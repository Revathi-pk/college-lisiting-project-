<?php
include 'php/database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get list of valid columns from the database
    $result = mysqli_query($conn, "SHOW COLUMNS FROM college_full_info");
    $valid_columns = [];

    while ($row = mysqli_fetch_assoc($result)) {
        $valid_columns[] = $row['Field'];
    }

    $fields = [];
    $values = [];

    foreach ($_POST as $key => $value) {
        if (in_array($key, $valid_columns)) {
            $fields[] = "`" . $key . "`";
            $values[] = "'" . mysqli_real_escape_string($conn, $value) . "'";
        }
    }

    if (!empty($fields)) {
        $sql = "INSERT INTO college_full_info (" . implode(",", $fields) . ") VALUES (" . implode(",", $values) . ")";
        
        if (mysqli_query($conn, $sql)) {
            echo json_encode(["status" => "success"]);
        } else {
            echo json_encode(["status" => "error", "message" => mysqli_error($conn)]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "No valid fields submitted."]);
    }
}
?>
