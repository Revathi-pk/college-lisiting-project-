console.log("JavaScript loaded!");

document.addEventListener('DOMContentLoaded', function() {
    console.log("JavaScript is running!");  // For debugging

    // Fetch filter options from backend
    fetch('php/get_filters.php')
        .then(response => response.json())
        .then(data => {
            console.log(data);  // Log the filter data

            // Populate dropdowns with the fetched data
            if (data.colleges) {
                populateDropdown('college_name', data.colleges);
            }
            if (data.states) {
                populateDropdown('state', data.states);
            }
            if (data.cities) {
                populateDropdown('city', data.cities);
            }
            if (data.courses) {
                populateDropdown('course', data.courses);
            }

            // Fetch all colleges on page load as default
            fetchColleges();
        })
        .catch(error => {
            console.error('Error fetching filter data:', error);
        });

    // Trigger the fetch function when filters are applied
    document.getElementById('filter_button').addEventListener('click', function() {
        fetchColleges();  // Call the function to fetch filtered colleges
    });

    function fetchColleges() {
        // Get selected filter values
        const college_name = document.getElementById('college_name').value;
        const state = document.getElementById('state').value;
        const city = document.getElementById('city').value;
        const course = document.getElementById('course').value;

        // Display loading message while fetching data
        document.getElementById('college_results').innerHTML = 'Loading...';

        // Make the API call to fetch filtered colleges
        fetch(`php/get_colleges.php?college_name=${college_name}&state=${state}&city=${city}&course=${course}`)
            .then(response => response.json())
            .then(data => {
                console.log(data);  // For debugging: log the filtered data
                displayColleges(data);
            })
            .catch(error => {
                console.error('Error fetching college data:', error);
            });
    }

    // Function to populate dropdown options
    function populateDropdown(elementId, values) {
        const dropdown = document.getElementById(elementId);
        dropdown.innerHTML = '<option value="">All</option>';  // Reset dropdown options
        values.forEach(value => {
            const option = document.createElement('option');
            option.value = value;
            option.textContent = value;
            dropdown.appendChild(option);
        });
    }

    

    // Function to display the fetched colleges in the UI
    function displayColleges(data) {
        let output = '';
        if (data.status === "success" && data.data.length > 0) {
            data.data.forEach(college => {
                output += `
                <div class="card">
                    <h3>${college.college_name}</h3>
                    <p><strong>State:</strong> ${college.state}</p>
                    <p><strong>City:</strong> ${college.city}</p>
                    <p><strong>Establishment Year:</strong> ${college.establishment_year}</p>
                    <p><strong>Coupon Code:</strong> ${college.coupon_code || 'N/A'}</p>
                    <p><strong>Application Link:</strong> <a href="${college.application_link}" target="_blank">${college.application_link}</a></p>
                    <p><strong>Ref Code:</strong> ${college.ref_code || 'N/A'}</p>
                </div>
                `;
            });
            document.getElementById('college_results').innerHTML = output;
        } else {
            document.getElementById('college_results').innerHTML = 'No colleges found';
        }
    }
});











document.addEventListener('DOMContentLoaded', function() {
    console.log("JavaScript is running!");  // Debugging: Check if JS is loaded

    // Fetch data from the backend
    fetch('php/get_colleges.php')
        .then(response => response.json())
        .then(data => {
            console.log(data);  // Log the response for debugging

            // Check if data is successful
            if (data.status === "success") {
                const colleges = data.data;
                let output = '';
                
                // Loop through each college and create HTML content
                colleges.forEach(college => {
                    output += `
                    <div class="card">
                        <h3>${college.college_name}</h3>
                        <p><strong>State:</strong> ${college.state}</p>
                        <p><strong>City:</strong> ${college.city}</p>
                        <p><strong>Establishment Year:</strong> ${college.establishment_year}</p>
                        <p><strong>Coupon Code:</strong> ${college.coupon_code || 'N/A'}</p>
                        <p><strong>Application Link:</strong> <a href="${college.application_link}" target="_blank">${college.application_link}</a></p>
                        <p><strong>Ref Code:</strong> ${college.ref_code || 'N/A'}</p>
                    </div>
                    `;
                });

                // Insert the HTML content into the results section
                document.getElementById('college_results').innerHTML = output;
            } else {
                document.getElementById('college_results').innerHTML = 'No colleges found';
            }
        })
        .catch(error => {
            console.error('Error fetching college data:', error);
        });
});



document.addEventListener('DOMContentLoaded', () => {
    const addCourseButton = document.createElement('button');
    addCourseButton.textContent = 'Add Another Course';
    addCourseButton.classList.add('btn', 'btn-secondary', 'mt-3');

    const courseContainer = document.querySelector('.course-container');
    courseContainer.appendChild(addCourseButton);


    addCourseButton.addEventListener('click', () => {
        const courseHTML = document.querySelector('.course').outerHTML;
        courseContainer.insertAdjacentHTML('beforeend', courseHTML);
    });
});

document.getElementById('collegeForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission

    const formData = new FormData(this);

    fetch('submit_college.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        console.log('Success:', data);
        // Optionally, show a success message or redirect
    })
    .catch(error => {
        console.error('Error:', error);
    });
});


// branches 

document.addEventListener('DOMContentLoaded', () => {
    const addBranchButton = document.createElement('button');
    addBranchButton.textContent = 'Add Another branch';
    addBranchButton.classList.add('btn', 'btn-secondary', 'mt-3');

    const branchContainer = document.querySelector('.course-block');
    courseContainer.appendChild(addCourseButton);


    addBranchButton.addEventListener('click', () => {
        const courseHTML = document.querySelector('.branch_fees').outerHTML;
        branchContainer.insertAdjacentHTML('beforeend', branchHTML);
    });
});


const feeRange = document.getElementById('feeRangeFilter').value.trim();
let min_fee = "", max_fee = "";

if (feeRange !== "" && feeRange.includes("-")) {
  [min_fee, max_fee] = feeRange.split("-").map(v => v.trim());
}
