<?php
include('php/database.php');

if (isset($_GET['id'])) {
    $college_id = $_GET['id'];
    $data = [];

    // Get college basic info
    $sql = "SELECT * FROM College WHERE college_id = $college_id";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $data['college'] = $result->fetch_assoc();
    }

    // Get course and branch fees
    $sql = "SELECT * FROM branch_fees WHERE college_id = $college_id";
    $result = $conn->query($sql);
    $data['courses'] = [];
    while ($row = $result->fetch_assoc()) {
        $row['branches'] = json_decode($row['branches'], true);
        $data['courses'][] = $row;
    }

    // Get hostel
    $sql = "SELECT * FROM Hostel WHERE college_id = $college_id";
    $result = $conn->query($sql);
    if ($result) {
        $data['hostel'] = $result->fetch_assoc();
    }

    // Get other fees
    $sql = "SELECT * FROM Other_Fees WHERE college_id = $college_id";
    $result = $conn->query($sql);
    if ($result) {
        $data['other_fees'] = $result->fetch_assoc();
    }

    echo json_encode($data);
} else {
    echo json_encode(["error" => "No ID given"]);
}
?>
