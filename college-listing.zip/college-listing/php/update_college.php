<?php
include 'database.php';
header('Content-Type: application/json');

if (!isset($_POST['id'])) {
    echo json_encode(["error" => "Missing college ID"]);
    exit;
}

$id = intval($_POST['id']);

// === Update College Basic Info ===
// All varchar fields must be bound as string "s"
$sql = "UPDATE college_full_info SET
    college_name = ?, university = ?, college_type = ?, establishment_year = ?,
    city = ?, state = ?, application_link = ?, coupon_code = ?, reference_code = ?,
    boys_single = ?, boys_double = ?, boys_triple = ?,
    girls_single = ?, girls_double = ?, girls_triple = ?,
    transportation_fee = ?, miscellaneous_fee = ?
    WHERE id = ?";

$stmt = mysqli_prepare($conn, $sql);
if (!$stmt) {
    echo json_encode(["error" => "Query preparation failed: " . mysqli_error($conn)]);
    exit;
}

mysqli_stmt_bind_param($stmt, "sssssssssssssssssi",
    $_POST['college_name'], $_POST['university'], $_POST['college_type'], $_POST['establishment_year'],
    $_POST['city'], $_POST['state'], $_POST['application_link'], $_POST['coupon_code'], $_POST['reference_code'],
    $_POST['boys_single'], $_POST['boys_double'], $_POST['boys_triple'],
    $_POST['girls_single'], $_POST['girls_double'], $_POST['girls_triple'],
    $_POST['transportation_fee'], $_POST['miscellaneous_fee'], $id
);

if (!mysqli_stmt_execute($stmt)) {
    echo json_encode(["error" => "Failed to update college info: " . mysqli_stmt_error($stmt)]);
    exit;
}
mysqli_stmt_close($stmt);

// === Update Courses and Branches ===
for ($course = 1; $course <= 3; $course++) {
    if (!isset($_POST["course{$course}_name"])) continue;
    $course_name = trim($_POST["course{$course}_name"]);

    // Check if course exists
    $course_id = null;
    $check_sql = "SELECT id FROM courses WHERE college_id = ? AND course_index = ?";
    $check_stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($check_stmt, "ii", $id, $course);
    mysqli_stmt_execute($check_stmt);
    mysqli_stmt_bind_result($check_stmt, $course_id);
    $exists = mysqli_stmt_fetch($check_stmt);
    mysqli_stmt_close($check_stmt);

    if ($exists) {
        // Update course
        $update_sql = "UPDATE courses SET course_name = ? WHERE id = ?";
        $update_stmt = mysqli_prepare($conn, $update_sql);
        mysqli_stmt_bind_param($update_stmt, "si", $course_name, $course_id);
        mysqli_stmt_execute($update_stmt);
        mysqli_stmt_close($update_stmt);
    } else {
        // Insert new course
        $insert_sql = "INSERT INTO courses (college_id, course_index, course_name) VALUES (?, ?, ?)";
        $insert_stmt = mysqli_prepare($conn, $insert_sql);
        mysqli_stmt_bind_param($insert_stmt, "iis", $id, $course, $course_name);
        mysqli_stmt_execute($insert_stmt);
        $course_id = mysqli_insert_id($conn);
        mysqli_stmt_close($insert_stmt);
    }

    // === Handle Branches for this course ===
    for ($branch = 1; $branch <= 5; $branch++) {
        $branch_name = $_POST["course{$course}_branch{$branch}_name"] ?? null;
        if (!$branch_name) continue;

        $reg_fee = floatval($_POST["course{$course}_branch{$branch}_reg_fee"] ?? 0);
        $total_fee = floatval($_POST["course{$course}_branch{$branch}_total_fee"] ?? 0);
        $inst1 = floatval($_POST["course{$course}_branch{$branch}_inst1"] ?? 0);
        $inst2 = floatval($_POST["course{$course}_branch{$branch}_inst2"] ?? 0);
        $inst3 = floatval($_POST["course{$course}_branch{$branch}_inst3"] ?? 0);
        $inst4 = floatval($_POST["course{$course}_branch{$branch}_inst4"] ?? 0);
        $inst5 = floatval($_POST["course{$course}_branch{$branch}_inst5"] ?? 0);

        // Check if branch exists
        $branch_id = null;
        $check_branch_sql = "SELECT id FROM branches WHERE course_id = ? AND branch_index = ?";
        $check_branch_stmt = mysqli_prepare($conn, $check_branch_sql);
        mysqli_stmt_bind_param($check_branch_stmt, "ii", $course_id, $branch);
        mysqli_stmt_execute($check_branch_stmt);
        mysqli_stmt_bind_result($check_branch_stmt, $branch_id);
        $branch_exists = mysqli_stmt_fetch($check_branch_stmt);
        mysqli_stmt_close($check_branch_stmt);

        if ($branch_exists) {
            // Update branch
            $update_branch_sql = "UPDATE branches SET 
                branch_name = ?, registration_fee = ?, total_fee = ?,
                inst1 = ?, inst2 = ?, inst3 = ?, inst4 = ?, inst5 = ?
                WHERE id = ?";
            $update_branch_stmt = mysqli_prepare($conn, $update_branch_sql);
            mysqli_stmt_bind_param($update_branch_stmt, "sdddddddi",
                $branch_name, $reg_fee, $total_fee, $inst1, $inst2, $inst3, $inst4, $inst5, $branch_id);
            mysqli_stmt_execute($update_branch_stmt);
            mysqli_stmt_close($update_branch_stmt);
        } else {
            // Insert new branch
            $insert_branch_sql = "INSERT INTO branches 
                (course_id, branch_index, branch_name, registration_fee, total_fee, inst1, inst2, inst3, inst4, inst5) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $insert_branch_stmt = mysqli_prepare($conn, $insert_branch_sql);
            mysqli_stmt_bind_param($insert_branch_stmt, "iisddddddd",
                $course_id, $branch, $branch_name, $reg_fee, $total_fee, $inst1, $inst2, $inst3, $inst4, $inst5);
            mysqli_stmt_execute($insert_branch_stmt);
            mysqli_stmt_close($insert_branch_stmt);
        }
    }
}

echo json_encode(["success" => true]);
