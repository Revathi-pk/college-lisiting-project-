<?php
// Database connection settings
$servername = "localhost";
$username = "college_college"; // your MySQL username
$password = "Planedu@123"; // your MySQL password
$dbname = "college_college"; // the database you want to connect to

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>