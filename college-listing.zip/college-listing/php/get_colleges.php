<?php
include('database.php');

$filter_conditions = [];

if (!empty($_GET['college_name'])) {
    $collegeName = mysqli_real_escape_string($conn, $_GET['college_name']);
    $filter_conditions[] = "college_name LIKE '%$collegeName%'";
}

if (!empty($_GET['state'])) {
    $state = mysqli_real_escape_string($conn, $_GET['state']);
    $filter_conditions[] = "state = '$state'";
}

if (!empty($_GET['city'])) {
    $city = mysqli_real_escape_string($conn, $_GET['city']);
    $filter_conditions[] = "city = '$city'";
}

if (!empty($_GET['college_type'])) {
    $college_type = mysqli_real_escape_string($conn, $_GET['college_type']);
    $filter_conditions[] = "college_type = '$college_type'";
}

if (!empty($_GET['course'])) {
    $course = mysqli_real_escape_string($conn, $_GET['course']);
    $filter_conditions[] = "(course1_name LIKE '%$course%' OR course2_name LIKE '%$course%' OR course3_name LIKE '%$course%')";
}

if (!empty($_GET['min_fee']) && !empty($_GET['max_fee'])) {
    $min_fee = (int) $_GET['min_fee'];
    $max_fee = (int) $_GET['max_fee'];
    
    $fee_conditions = [];
    for ($course = 1; $course <= 3; $course++) {
        for ($branch = 1; $branch <= 3; $branch++) {
            $fee_conditions[] = "(course{$course}_branch{$branch}_total_fee BETWEEN $min_fee AND $max_fee)";
        }
    }

    $filter_conditions[] = '(' . implode(' OR ', $fee_conditions) . ')';
}



$where_clause = count($filter_conditions) > 0 ? "WHERE " . implode(" AND ", $filter_conditions) : "";

$sql = "SELECT id, college_name, state, city, college_type, course1_name, course2_name, course3_name FROM college_full_info $where_clause ORDER BY created_at DESC";

$result = mysqli_query($conn, $sql);

$colleges = [];
while ($row = mysqli_fetch_assoc($result)) {
    $colleges[] = $row;
}

echo json_encode($colleges);
?>
