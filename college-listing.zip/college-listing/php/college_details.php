<?php
include 'database.php'; // Ensure the path is correct

header('Content-Type: application/json');

if (!isset($_GET['id'])) {
    echo json_encode(["error" => "Missing college ID"]);
    exit;
}

$id = intval($_GET['id']); // Sanitize the ID

// Prepared statement to prevent SQL injection
$sql = "SELECT * FROM college_full_info WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);

if ($stmt === false) {
    echo json_encode(["error" => "Database query preparation failed: " . mysqli_error($conn)]);
    exit;
}

// Bind the ID parameter to the prepared statement
mysqli_stmt_bind_param($stmt, "i", $id);

// Execute the statement
mysqli_stmt_execute($stmt);

// Get the result
$result = mysqli_stmt_get_result($stmt);

if ($row = mysqli_fetch_assoc($result)) {
    echo json_encode($row);
} else {
    echo json_encode(["error" => "College not found"]);
}

// Close the statement
mysqli_stmt_close($stmt);
?>
