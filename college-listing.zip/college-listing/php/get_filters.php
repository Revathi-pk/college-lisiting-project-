<?php
include('php/database.php');

// Initialize filters array
$filters = [];

// Fetch distinct college names
$sql_college = "SELECT DISTINCT college_name FROM college_full_info WHERE college_name IS NOT NULL";
$result_college = $conn->query($sql_college);
$filters['colleges'] = [];
while ($row = $result_college->fetch_assoc()) {
    $filters['colleges'][] = $row['college_name'];
}

// Fetch distinct states
$sql_state = "SELECT DISTINCT state FROM college_full_info WHERE state IS NOT NULL";
$result_state = $conn->query($sql_state);
$filters['states'] = [];
while ($row = $result_state->fetch_assoc()) {
    $filters['states'][] = $row['state'];
}

// Fetch distinct cities
$sql_city = "SELECT DISTINCT city FROM college_full_info WHERE city IS NOT NULL";
$result_city = $conn->query($sql_city);
$filters['cities'] = [];
while ($row = $result_city->fetch_assoc()) {
    $filters['cities'][] = $row['city'];
}

// Fetch distinct courses from all 3 course columns
$sql_course = "
    SELECT DISTINCT course1_name AS course FROM college_full_info WHERE course1_name IS NOT NULL
    UNION
    SELECT DISTINCT course2_name AS course FROM college_full_info WHERE course2_name IS NOT NULL
    UNION
    SELECT DISTINCT course3_name AS course FROM college_full_info WHERE course3_name IS NOT NULL
";
$result_course = $conn->query($sql_course);
$filters['courses'] = [];
while ($row = $result_course->fetch_assoc()) {
    $filters['courses'][] = $row['course'];
}




// Return the filters as JSON
echo json_encode($filters);

$conn->close();
?>
